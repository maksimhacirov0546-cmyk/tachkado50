/**
 * Тачка до 50т₽ — клиентская логика демо-версии
 * Объявления хранятся только в localStorage браузера (демо).
 * Реальные данные из VK API / бэкенда не подключены.
 */

(function () {
  'use strict';

  const STORAGE_KEY = 'tachka_do_50_ads_v1';

  // ---------- Helpers ----------
  function loadAds() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  }

  function saveAds(ads) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(ads));
  }

  function formatPrice(n) {
    return new Intl.NumberFormat('ru-RU').format(n) + ' ₽';
  }

  function getQueryParams() {
    return new URLSearchParams(window.location.search);
  }

  // ---------- Mobile nav & filters ----------
  const burger = document.getElementById('burger');
  const mainNav = document.getElementById('mainNav');
  if (burger && mainNav) {
    burger.addEventListener('click', () => {
      mainNav.classList.toggle('open');
    });
  }

  const filters = document.getElementById('filters');
  const filtersToggle = document.getElementById('filtersToggle');
  const filtersClose = document.getElementById('filtersClose');
  if (filtersToggle && filters) {
    filtersToggle.addEventListener('click', () => filters.classList.add('open'));
  }
  if (filtersClose && filters) {
    filtersClose.addEventListener('click', () => filters.classList.remove('open'));
  }

  // ---------- Catalog page ----------
  const catalogGrid = document.getElementById('catalogGrid');
  const emptyState = document.getElementById('emptyState');
  const resultsCount = document.getElementById('resultsCount');
  const cardTemplate = document.getElementById('cardTemplate');

  function renderCatalog(ads) {
    if (!catalogGrid) return;

    // Clear previous cards (keep emptyState node)
    catalogGrid.querySelectorAll('.card').forEach(el => el.remove());

    if (!ads || ads.length === 0) {
      if (emptyState) emptyState.style.display = 'block';
      if (resultsCount) resultsCount.textContent = 'Объявлений: 0';
      return;
    }

    if (emptyState) emptyState.style.display = 'none';
    if (resultsCount) resultsCount.textContent = 'Объявлений: ' + ads.length;

    ads.forEach(ad => {
      const node = cardTemplate.content.cloneNode(true);
      const article = node.querySelector('.card');
      article.dataset.id = ad.id;

      const link = node.querySelector('.card__link');
      link.href = 'ad.html?id=' + encodeURIComponent(ad.id);

      const img = node.querySelector('img');
      if (ad.imageDataUrl) {
        img.src = ad.imageDataUrl;
        img.alt = ad.title;
      } else {
        img.remove();
        const placeholder = document.createElement('div');
        placeholder.style.cssText = 'width:100%;height:100%;display:flex;align-items:center;justify-content:center;background:#e5e7eb;color:#9ca3af;font-size:2rem;';
        placeholder.textContent = ad.type === 'part' ? '🔧' : '🚗';
        node.querySelector('.card__image').appendChild(placeholder);
      }

      const badge = node.querySelector('.card__badge');
      badge.textContent = ad.type === 'part' ? 'Запчасть' : 'Авто';

      node.querySelector('.card__price').textContent = formatPrice(ad.price);
      node.querySelector('.card__title').textContent = ad.title;

      const metaParts = [];
      if (ad.brand) metaParts.push(ad.brand);
      if (ad.year) metaParts.push(ad.year + ' г.');
      if (ad.condition) {
        const condMap = { excellent: 'Отл.', good: 'Хор.', average: 'Средн.', 'for-parts': 'На з/ч' };
        metaParts.push(condMap[ad.condition] || ad.condition);
      }
      node.querySelector('.card__meta').textContent = metaParts.join(' · ');
      node.querySelector('.card__location').textContent = ad.city || 'Город не указан';

      catalogGrid.appendChild(node);
    });
  }

  function applyFiltersAndSort() {
    let ads = loadAds();

    const q = (document.getElementById('searchQuery')?.value || '').trim().toLowerCase();
    const category = document.getElementById('searchCategory')?.value || 'all';
    const priceFrom = parseInt(document.getElementById('priceFrom')?.value, 10) || 0;
    const priceTo = parseInt(document.getElementById('priceTo')?.value, 10) || 50000;
    const typeRadio = document.querySelector('input[name="type"]:checked');
    const type = typeRadio ? typeRadio.value : 'all';
    const brand = document.getElementById('filterBrand')?.value || '';
    const yearFrom = parseInt(document.getElementById('yearFrom')?.value, 10) || 0;
    const yearTo = parseInt(document.getElementById('yearTo')?.value, 10) || 9999;
    const city = (document.getElementById('filterCity')?.value || '').trim().toLowerCase();
    const conditions = Array.from(document.querySelectorAll('input[name="condition"]:checked')).map(el => el.value);
    const sortBy = document.getElementById('sortBy')?.value || 'newest';

    ads = ads.filter(ad => {
      if (ad.price > 50000) return false; // hard limit of the community
      if (q && !(ad.title.toLowerCase().includes(q) || (ad.description || '').toLowerCase().includes(q) || (ad.brand || '').toLowerCase().includes(q))) return false;
      if (category !== 'all' && ad.type !== category) return false;
      if (type !== 'all' && ad.type !== type) return false;
      if (ad.price < priceFrom || ad.price > priceTo) return false;
      if (brand && ad.brand !== brand) return false;
      if (ad.type === 'car') {
        if (ad.year && (ad.year < yearFrom || ad.year > yearTo)) return false;
      }
      if (city && !(ad.city || '').toLowerCase().includes(city)) return false;
      if (conditions.length && !conditions.includes(ad.condition)) return false;
      return true;
    });

    ads.sort((a, b) => {
      if (sortBy === 'price-asc') return a.price - b.price;
      if (sortBy === 'price-desc') return b.price - a.price;
      return (b.createdAt || 0) - (a.createdAt || 0);
    });

    renderCatalog(ads);
  }

  // Bind catalog events
  if (catalogGrid) {
    const searchForm = document.getElementById('searchForm');
    if (searchForm) {
      searchForm.addEventListener('submit', e => {
        e.preventDefault();
        applyFiltersAndSort();
      });
    }
    document.getElementById('applyFilters')?.addEventListener('click', () => {
      applyFiltersAndSort();
      filters?.classList.remove('open');
    });
    document.getElementById('resetFilters')?.addEventListener('click', () => {
      document.getElementById('priceFrom').value = '';
      document.getElementById('priceTo').value = '';
      document.getElementById('filterBrand').value = '';
      document.getElementById('yearFrom').value = '';
      document.getElementById('yearTo').value = '';
      document.getElementById('filterCity').value = '';
      document.querySelectorAll('input[name="condition"]').forEach(el => el.checked = false);
      document.querySelector('input[name="type"][value="all"]').checked = true;
      document.getElementById('searchQuery').value = '';
      document.getElementById('searchCategory').value = 'all';
      applyFiltersAndSort();
    });
    document.getElementById('sortBy')?.addEventListener('change', applyFiltersAndSort);

    // Initial render
    applyFiltersAndSort();
  }

  // ---------- Ad detail page ----------
  const adDetailRoot = document.getElementById('adDetail');
  if (adDetailRoot) {
    const params = getQueryParams();
    const id = params.get('id');
    const ads = loadAds();
    const ad = ads.find(a => String(a.id) === String(id));

    if (!ad) {
      adDetailRoot.innerHTML = `
        <div class="empty-state">
          <div class="empty-state__icon">🔍</div>
          <h3>Объявление не найдено</h3>
          <p>Возможно, оно было удалено или ссылка устарела. В демо-версии данные хранятся только в вашем браузере.</p>
          <a href="index.html" class="btn btn--primary">Вернуться в каталог</a>
        </div>`;
    } else {
      const condMap = {
        excellent: 'Отличное',
        good: 'Хорошее',
        average: 'Среднее',
        'for-parts': 'На запчасти'
      };
      adDetailRoot.innerHTML = `
        <div class="ad-layout">
          <div>
            <div class="ad-gallery">
              <div class="ad-gallery__main">
                ${ad.imageDataUrl
                  ? `<img src="${ad.imageDataUrl}" alt="${escapeHtml(ad.title)}" style="width:100%;height:100%;object-fit:cover;">`
                  : (ad.type === 'part' ? '🔧 Фото запчасти' : '🚗 Фото автомобиля')}
              </div>
            </div>
            <div class="ad-info" style="margin-top:16px;">
              <h2 style="font-size:1.1rem;margin-bottom:12px;">Описание</h2>
              <div class="ad-info__desc">${escapeHtml(ad.description || 'Описание не указано.')}</div>
            </div>
          </div>
          <div>
            <div class="ad-info">
              <div class="ad-info__price">${formatPrice(ad.price)}</div>
              <h1 class="ad-info__title">${escapeHtml(ad.title)}</h1>
              <div class="ad-info__meta">
                ${ad.brand ? `<span>${escapeHtml(ad.brand)}</span>` : ''}
                ${ad.year ? `<span>${ad.year} г.</span>` : ''}
                ${ad.condition ? `<span>${condMap[ad.condition] || ad.condition}</span>` : ''}
                ${ad.city ? `<span>📍 ${escapeHtml(ad.city)}</span>` : ''}
              </div>
              <div class="seller-card">
                <div class="seller-card__name">${escapeHtml(ad.sellerName || 'Продавец')}</div>
                <div style="font-size:0.85rem;color:#6b7280;">Контакты продавца</div>
                <div class="seller-card__contact">
                  ${ad.phone ? `<a href="tel:${escapeHtml(ad.phone)}">📞 ${escapeHtml(ad.phone)}</a>` : ''}
                  ${ad.vkLink ? `<a href="${escapeHtml(ad.vkLink)}" target="_blank" rel="noopener">VK профиль / сообщение</a>` : ''}
                  ${!ad.phone && !ad.vkLink ? '<span style="color:#9ca3af;font-size:0.9rem;">Контакты не указаны</span>' : ''}
                </div>
              </div>
              <p style="margin-top:16px;font-size:0.8rem;color:#9ca3af;">ID: ${escapeHtml(String(ad.id))} · Демо-данные в localStorage</p>
            </div>
          </div>
        </div>`;
    }
  }

  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  // ---------- Add form page ----------
  const addForm = document.getElementById('addForm');
  if (addForm) {
    addForm.addEventListener('submit', function (e) {
      e.preventDefault();

      const title = document.getElementById('title').value.trim();
      const price = parseInt(document.getElementById('price').value, 10);
      const type = document.getElementById('type').value;
      const brand = document.getElementById('brand').value;
      const year = parseInt(document.getElementById('year').value, 10) || null;
      const condition = document.getElementById('condition').value;
      const city = document.getElementById('city').value.trim();
      const description = document.getElementById('description').value.trim();
      const sellerName = document.getElementById('sellerName').value.trim();
      const phone = document.getElementById('phone').value.trim();
      const vkLink = document.getElementById('vkLink').value.trim();
      const imageInput = document.getElementById('image');

      if (!title || !price || price < 1 || price > 50000) {
        alert('Укажите название и цену от 1 до 50 000 ₽.');
        return;
      }

      const ad = {
        id: 'local_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8),
        title,
        price,
        type,
        brand: brand || null,
        year: type === 'car' ? year : null,
        condition: condition || null,
        city: city || null,
        description,
        sellerName: sellerName || null,
        phone: phone || null,
        vkLink: vkLink || null,
        imageDataUrl: null,
        createdAt: Date.now()
      };

      const file = imageInput?.files?.[0];
      if (file) {
        if (file.size > 2 * 1024 * 1024) {
          alert('Изображение слишком большое (макс. 2 МБ для демо).');
          return;
        }
        const reader = new FileReader();
        reader.onload = function () {
          ad.imageDataUrl = reader.result;
          finishSave(ad);
        };
        reader.readAsDataURL(file);
      } else {
        finishSave(ad);
      }
    });

    function finishSave(ad) {
      const ads = loadAds();
      ads.unshift(ad);
      saveAds(ads);
      alert('Объявление сохранено локально в этом браузере (демо).\nОно появится в каталоге. Для реальной публикации нужна интеграция с VK / бэкендом.');
      window.location.href = 'index.html';
    }
  }
})();
